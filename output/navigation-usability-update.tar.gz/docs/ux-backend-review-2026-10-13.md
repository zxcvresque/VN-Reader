# Reader usability and backend review · 13 October 2026

This review uses the local source and a sample-data browser preview. It is a
targeted navigation repair and usability audit, not a production traffic audit.

## Fixed in this update

- Read, Threads, Bookmarks and Progress now mount one stable navigation restore
  slot. Mobile uses the same hamburger and dismissible hint on every page.
- Page toolbars sit outside the scrolling content. Revealing navigation cannot
  place a floating Progress title across the timeline chart.
- The mobile dock is 64px high with 44px controls. It uses compact icons and
  reserves consistent space above the content.
- Focus is available only on Read. Leaving Read exits focus, including removing
  its floating Exit focus control and layout from the destination page.
- Auto-hidden mobile navigation closes after choosing a page, including an
  empty Bookmarks page that has nothing to scroll.
- The hide-navigation label and mobile tooltip describe the current context.
  Mobile reading menus anchor below the current toolbar rather than a fixed
  offset that only fitted the old dock.
- The scrolling page regions are keyboard-focusable. Help text explains
  global toolbar restoration and Read-only focus.

The original logo, fonts, colors, theme palettes, chart series and navigation
destinations remain in use. The user explicitly required retaining colors.

## Concrete remaining gaps

| Priority | Finding | User impact | Recommended change |
| --- | --- | --- | --- |
| High | The media failure UI reads `X-Media-Status` for expired previews but ignores `Retry-After` for Telegram cooldowns. | A normal pause looks like broken media, and the Retry button invites retries that cannot succeed yet. | Show a countdown and retry visible failed media once the advertised cooldown ends; retain playback position. |
| High | The initial account session lookup runs once, silently catches network failures, and is not rerun by Retry connection. | A returning signed-in reader can remain in guest mode after the account service recovers. | Retry session discovery on explicit connection retry and network recovery, while preserving separate guest/account data. |
| Medium | The app fetches the entire archive every minute, recomputes threads and rewrites the full IndexedDB archive even when no posts changed. | Unnecessary mobile bandwidth, battery use and storage writes; repeated work increases with archive size. | Add an archive revision/ETag and conditional responses, then update the cache only when the revision changes. |
| Medium | Page/post navigation lives in React state and the reader's own trail, with no post/view URL state. | Readers cannot share an exact hosted post or rely on browser/phone Back to traverse reading locations. | Add stable post/view URLs and browser-history integration while preserving paragraph restoration. |
| Low | Signup always sends `name: "Reader"`; the form has no display-name field. | Account notifications can identify email and ID but cannot show a useful chosen reader name. | Add an optional display name to signup/account settings and keep email/ID as the reliable identifiers. |
| Low | Timeline content filters become a long single column on a 320px phone. | Filters take substantial space before the chart. | Use a compact phone layout or a collapsible Filters control with an active-filter count, retaining the existing colors and accessible labels. |

Evidence is in `src/components/MessageCard.tsx`, `src/lib/useReaderAccount.ts`,
`src/lib/api.ts`, `src/App.tsx`, `src/components/ReaderAccount.tsx`,
`src/components/PostTimeline.tsx` and `server/telegram.py`.

## Design audit and verification

Tasteskill mode: redesign with preservation. This is product UI, so its
marketing-page composition rules do not apply. The applicable guidance is the
audit-first approach, spacing, hierarchy, consistent sizing and accessibility.
Design variance 3, motion intensity 2, visual density 4: focused navigation,
minimal motion, enough visible controls for a reading tool. The implementation
uses the existing React/native CSS system and Radix icons. No UI dependency was
added. The user's color lock overrides the skill's color-recalibration guidance.

- Production TypeScript/Vite build passed.
- Complete JavaScript suite: 162 tests passed.
- Browser checks at 320px, 390px and 1280px covered page switching, hidden and
  revealed navigation, toolbar/content bounds, overflow and Focus visibility.
- Component tests cover every main view and all four dock positions, plus
  exiting focus when changing pages and closing navigation on empty pages.
- Browser screenshots are saved under `output/qa-mobile-nav/`.
- No production deployment was performed. Performance metrics and production
  traffic were not measured; the archive-refresh finding is based on source.
